# FutureAI Website

Готовый лендинг для публикации на GitHub Pages.

1. Создай репозиторий
2. Загрузи эти файлы
3. Включи Pages в Settings → Pages